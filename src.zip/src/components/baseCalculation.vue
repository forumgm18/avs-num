<!--<template>-->
<!--    <div class="row">-->
<!--        <el-input  placeholder="Фамилия"  v-model="fam"  clearable>  </el-input>-->
<!--        <div class="num-str"> {{ numStr }} </div>-->
<!--        <div class="num-str"> {{ arkStr }} </div>-->
<!--    </div>-->
<!--</template>-->

<!--<script>-->
<!--    export default {-->
<!--        name: "stringArkan",-->
<!--        props: {-->
<!--            numStr: String,-->
<!--            arkStr: Number,-->
<!--        }-->

<!--    }-->
<!--</script>-->

<!--<style scoped>-->

<!--</style>-->

<template>
  <div class="base-info">
      <div class="row source-info header">
          <div class="head-name"></div>
          <div class="el-input__inner1 num-str ">Цифрами</div>
          <div class="el-input__inner1 num-str ark">Аркан</div>
      </div>
      <div class="row source-info">
          <el-input  placeholder="Фамилия"  v-model="fam"  clearable>  </el-input>
          <div class="el-input__inner num-str"> {{fam | strToNumStr }} </div>
          <div class="el-input__inner num-str ark"> {{fam | strToArkan }} </div>
      </div>
      <div class="row source-info">
          <el-input  placeholder="Имя"  v-model="name"  clearable>  </el-input>
          <div class="el-input__inner num-str"> {{ name | strToNumStr }} </div>
          <div class="el-input__inner num-str ark"> {{ name | strToArkan }} </div>
      </div>
      <div class="row source-info">
          <el-input  placeholder="Отчество"  v-model="otch"  clearable>  </el-input>
          <div class="el-input__inner num-str"> {{otch |strToNumStr }} </div>
          <div class="el-input__inner num-str ark"> {{otch | strToArkan }} </div>
      </div>
      <div class="row date-info">

          <template>
              <div class="block">
                  <div class="label">Дата Рождения:</div>
                  <div class="date-retro">
                      <el-date-picker
                          v-model="date"
                          type="date"
                          format="dd.MM.yyyy"
                          value-format="yyyy-MM-dd"
                          placeholder="Дата рождения">
                      </el-date-picker>
                      <el-checkbox v-model="retro">Ретроградный</el-checkbox>
                  </div>
              </div>
          </template>
          <div class="matrix-code">
              <div class="label">Матричный код</div>
              <div class="matrix-content">
                  <div v-if="retro">
                      <span>Ретроградно:</span>
                      <span>{{matrixCode}}</span>
                  </div>
                  <div>
                      <span>Истинный:</span>
                      <span>{{trueMatrixCode}}</span>
                  </div>
              </div>
          </div>
      </div>

  </div>
  <h2>Базовый расчет</h2>
  <div class="base-table">
      <div class="row">
          <tab-cell cel-num="13" cel-title="Воспр. себя" :cel-value="selfPerception" > </tab-cell>
          <tab-cell cel-num="" cel-title='Черты хр-ра в "-"' :cel-value="traitsMinus" > </tab-cell>
          <tab-cell cel-num="14" cel-title="Воспр. окруж." :cel-value="perceptionByOthers" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="1" cel-title="Аркан Дня" :cel-value="arkDay" > </tab-cell>
          <tab-cell cel-num="2" cel-title="Аркан Месяца" :cel-value="arkMonth" > </tab-cell>
          <tab-cell cel-num="3" cel-title="Аркан Года" :cel-value="arkYear" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="" cel-title="Нер.цель" :cel-value="unrealizedGoal" > </tab-cell>
          <tab-cell cel-num="4" cel-title="АД + АМ" :cel-value="ADplusAM" > </tab-cell>
          <tab-cell cel-num="5" cel-title="АМ + АГ" :cel-value="AMplusAY" > </tab-cell>
          <tab-cell cel-num="" cel-title="Будущее" :cel-value="Future" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="9" cel-title="ОПВ-1" :cel-value="OPV1" > </tab-cell>
          <tab-cell cel-num="6" cel-title="Зона комфорта" :cel-value="ZK" > </tab-cell>
          <tab-cell cel-num="7" cel-title="Предназначение" :cel-value="Mission" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="8" cel-title="Инструмент" :cel-value="Instrument" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="8а" cel-title="Стимул" :cel-value="Stimul" > </tab-cell>
      </div>
      <div class="row">
          <tab-cell cel-num="" cel-title="Хлопоты" :cel-value="Troubles" > </tab-cell>
      </div>
  </div>
  <h2>Таблица</h2>
  <div class="table">
    <div class="row">
          <div class="cell"></div>
          <div class="cell">
              <span class="cel-num">1 Период</span><br>
              <span class="cel-title">до {{numberOfLife}}</span>
          </div>
          <div class="cell">
              <span class="cel-num">2 Период</span><br>
              <span class="cel-title">{{numberOfLife}} - {{p2}}</span>
          </div>
          <div class="cell">
              <span class="cel-num">3 Период</span><br>
              <span class="cel-title">{{p2}} - {{p3}}</span>
          </div>
          <div class="cell">
              <span class="cel-num">4 Период</span><br>
              <span class="cel-title">{{p3}} - {{p4}}</span>
          </div>
          <div class="cell">
              <span class="cel-num">5 Период</span><br>
              <span class="cel-title">{{p4}} - {{p5}}</span>
          </div>
    </div>
    <div class="row">
          <div class="cell"></div>
          <div class="cell">{{arkDay}}</div>
          <div class="cell">{{arkMonth}}</div>
          <div class="cell">{{arkYear}}</div>
          <div class="cell">{{arkNumberOfLife}}</div>
          <div class="cell">{{Mission}}</div>
    </div>
    <div class="row">
          <div class="cell">Крыша</div>
          <div class="cell">{{roof1}}</div>
          <div class="cell">{{roof2}}</div>
          <div class="cell">{{roof3}}</div>
          <div class="cell">{{roof4}}</div>
          <div class="cell">{{roof5}}</div>
      </div>
    <div class="row">
        <div class="cell">ТП</div>
        <div class="cell">{{TP1}}</div>
        <div class="cell">{{TP2}}</div>
        <div class="cell">{{TP3}}</div>
        <div class="cell">{{TP4}}</div>
        <div class="cell">{{TP5}}</div>
    </div>
    <div class="row">
        <div class="cell">ОПВ</div>
        <div class="cell">{{OPV1}}</div>
        <div class="cell">{{OPV2}}</div>
        <div class="cell">{{OPV3}}</div>
        <div class="cell">{{OPV4}}</div>
        <div class="cell">{{OPV5}}</div>
    </div>
    <div class="row">
        <div class="cell">Подвал</div>
        <div class="cell">{{footer1}}</div>
        <div class="cell">{{footer2}}</div>
        <div class="cell">{{footer3}}</div>
        <div class="cell">{{footer4}}</div>
        <div class="cell">{{footer5}}</div>
    </div>

  </div>
</template>

<script>
    import * as func from './functions.js';
    import tabCell from './components/tabCell.vue'


    export default {
        name: 'baseCalculation',
        components: { tabCell },
        props:['user'],
        data() {
            return {

                fam: '',
                name: '',
                otch: '',
                vin: '',
                carNum: '',
                text: '',
                date: '1981-08-02',
                retro: false,



            }
        },
        filters: {
            charToNum: function(s) {return func.charToNum(s);},
            strToNum: function(s) {return func.strToNum(s); },
            strToNumStr: function(s) { return func.strToNumStr(s);},
            strToArkan: function(s) {return func.strToArkan(s); }


        },
        computed: {
            arkDay: function () { return  func.ArkDay(this.date).toString() || ''; },
            arkMonth: function () { return  func.ArkMonth(this.date).toString() || ''; },
            arkYear: function () { return  func.ArkYear(this.date).toString() || ''; },
            ADplusAM: function () { return  func.ADplusAM(this.date).toString() || ''; },
            AMplusAY: function () { return  func.AMplusAY(this.date).toString() || ''; },
            ZK: function () { return  func.ZK(this.date).toString() || ''; },
            Mission: function () { return  func.Mission(this.date).toString() || ''; },
            unrealizedGoal: function () { return  func.unrealizedGoal(this.date).toString() || ''; },
            Future: function () { return  func.future(this.date).toString() || ''; },
            Instrument: function () { return  func.Instrument(this.date).toString() || ''; },
            Stimul: function () { return  func.Stimul(this.date).toString() || ''; },
            Troubles: function () { return  func.Troubles(this.date).toString() || ''; },
            perceptionByOthers: function () { return  func.perceptionByOthers(this.date).toString() || ''; },
            selfPerception: function () { return  func.selfPerception(this.date).toString() || ''; },
            traitsMinus: function () { return  func.traitsMinus(this.date).toString() || ''; },
            numberOfLife: function () { return  func.numberOfLife(this.date).toString() || ''; },
            arkNumberOfLife: function () { return  func.ArkNumberOfLife(this.date).toString() || ''; },
            p2: function () { return  (func.numberOfLife(this.date) + 9).toString() || ''; },
            p3: function () { return  (func.numberOfLife(this.date) + 18).toString() || ''; },
            p4: function () { return  (func.numberOfLife(this.date) + 27).toString() || ''; },
            p5: function () { return  (func.numberOfLife(this.date) + 36).toString() || ''; },
            TP1: function () { return  func.TP1(this.date).toString() || ''; },
            TP2: function () { return  func.TP2(this.date).toString() || ''; },
            TP3: function () { return  func.TP3(this.date).toString() || ''; },
            TP4: function () { return  func.TP4(this.date).toString() || ''; },
            TP5: function () { return  func.TP5(this.date).toString() || ''; },
            OPV1: function () { return  func.OPV1(this.date).toString() || ''; },
            OPV2: function () { return  func.OPV2(this.date).toString() || ''; },
            OPV3: function () { return  func.OPV3(this.date).toString() || ''; },
            OPV4: function () { return  func.OPV4(this.date).toString() || ''; },
            OPV5: function () { return  func.OPV5(this.date).toString() || ''; },

            roof1: function () { return  func.roof1(this.date).toString() || ''; },
            roof2: function () { return  func.roof2(this.date).toString() || ''; },
            roof3: function () { return  func.roof3(this.date).toString() || ''; },
            roof4: function () { return  func.roof4(this.date).toString() || ''; },
            roof5: function () { return  func.roof5(this.date).toString() || ''; },

            footer1: function () { return  func.footer1(this.date).toString() || ''; },
            footer2: function () { return  func.footer2(this.date).toString() || ''; },
            footer3: function () { return  func.footer3(this.date).toString() || ''; },
            footer4: function () { return  func.footer4(this.date).toString() || ''; },
            footer5: function () { return  func.footer5(this.date).toString() || ''; },

            matrixCode: function () { return  func.matrixCode(this.date) || 0; }, // Матричный код (или ретроградный)
            trueMatrixCode: function () { return  func.trueMatrixCode(this.date, this.retro) || 0; }, // Истинный Матричный код в случае ретроградности


        },
        // whatch: {
        //     date : function (val) {
        //         let s = func.ArkDay(val).toString();
        //         console.log('arkDay: ',s);
        //         this.arkDay =  s || '';
        //     }
        // }


    }

</script>

<style scoped>
    .row {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 15px;
    }
    .header > div {   text-align: center;}

    .date-info > div {
        margin-bottom: 15px;
        width: calc( 50% - 15px);
    }
    .num-str:not(.ark){   font-size: 14px;}
    .date-info > div:not(:last-child) {  margin-right: 15px;}

    .source-info > div {   width: calc( 33% - 15px); }
    .source-info > div:not(:last-child) {   margin-right: 15px; }
    .base-table,.base-info{  margin-bottom: 50px;  padding: 15px 0;}
    .base-table .row > div{  width: calc( 100% / 5);}
    .base-table .row > div:not(:last-child){ margin-right: 2px;}
    .base-table .row {
        justify-content: center;
        margin-bottom: 2px;
    }

    .table .row {
        flex-wrap: nowrap;
        margin-bottom: 0;
    }
    .table {border: 1px solid gray;}
    .table .row {border: 0px solid gray;}
    .table .row .cell {
        max-width: calc( 100% / 6);
        width: calc( 100% / 6);
        border: 0px solid gray;
        margin-right: 0;
        text-align: center;
        line-height: 30px;
        font-size: 18px;
        color: #333;
    }

    .table .row:not(:last-child) {  border-bottom-width: 1px;}
    .table .cell:not(:last-child) {  border-right-width: 1px;}

    .block > div {    width: 100%!important;}
    .block .label {    text-align: left;}
    .textarea { height: initial;  align-self: stretch;  font-size: 14px;}

    .date-retro {
        display: flex;
        align-items: center;
    }
    .date-retro > div {
        margin-right: 30px;
        min-width: 140px;
    }
    .matrix-code {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
    }
    .matrix-code > div {
        text-align: left;
        width: 100%;
        max-width: 100%;
    }
    .matrix-content {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        /*justify-content: space-between;*/
        min-height: 40px;
    }
    .matrix-content > div  {  width: 140px;}
    .matrix-content > div span:first-child {
        min-width: 100px;
        margin-right: 15px;
        font-size: .8em;
    }
    .matrix-content > div span:last-child {  font-weight: bold;}

    .date-info > div {  width: 48%;}


    .additionally {
        text-align: left;

    }
    .additionally-content {
        overflow: hidden;
        transition: .5s;
        max-height: 0;
        background-color: #f3f3f3;

    }
    .additionally-content.show {  max-height: 500px;  padding: 15px 0;}
    .additionally-link {
        display: flex;
        align-items: center;
        margin-bottom: 30px;
        color: #333;
        text-decoration: none;
        cursor: pointer;
    }
    .additionally-link:hover {
        color: #999;
        text-decoration: none;
    }
    .additionally-link:after {
        content: '';
        display: block;
        width: 8px;
        height: 8px;
        border: 0px solid #333;
        border-right-width: 1px;
        border-bottom-width: 1px;
        transform: rotate(45deg);
        transition: .5s;
        margin-left: 15px;
        margin-bottom: 3px;
    }
    .additionally-link.show:after {
        transform: rotate(225deg);
        margin-bottom: -6px;
    }


    @media (max-width: 500px) {
        .table .row .cell {   font-size: 12px;}
        .date-retro {justify-content: space-between;}
        .date-retro > div { max-width: 50%;}
        .matrix-code {justify-content: space-between;}
        .matrix-code > div { width: 100%;}
        /*.matrix-content > div  {  width: 48%;}*/


    }
    @media (max-width: 600px) {
        .base-info .row  { margin-bottom: 20px;}
        .source-info > div:first-child {
            max-width: unset;
            width: 100%;
            margin-bottom: 10px;
            margin-right: 0;
        }
        .source-info > div:nth-child(2) {
            max-width: unset;
            flex: 1 1 auto;

        }
        .row.header { font-size: 14px; }
        .date-info > div {  width: 100%;}
    }
</style>
